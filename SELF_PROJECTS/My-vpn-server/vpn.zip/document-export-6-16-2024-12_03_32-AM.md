# How VPN works?



